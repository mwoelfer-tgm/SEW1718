model Module
============

:mod:`model` Module
-------------------

.. automodule:: model
    :members:
    :undoc-members:
    :special-members: __init__
    :show-inheritance:
