ChannelDecorator Module
=======================

:mod:`ChannelDecorator` Module
------------------------------

.. automodule:: ChannelDecorator
    :members:
    :undoc-members:
    :special-members: __init__
    :show-inheritance:
